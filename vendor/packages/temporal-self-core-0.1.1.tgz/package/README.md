# Temporal Self Lab

Temporal Self Lab is a small TypeScript kernel for interactive experiments about time, memory, self-reference, changing rules, and counterfactual futures.

It deliberately does **not** decide whether a system is alive, agentic, self-aware, or genuinely represents time. It gives products and experiments a common way to expose the evidence behind those claims.

## What the kernel standardizes

- **Deterministic execution** from a declared seed.
- **Event-sourced histories** with state before and after every action.
- **Fork and replay** so two futures can begin from the same recorded past.
- **Interventions** as first-class operations, separate from ordinary evolution.
- **Layer declarations** for state, policy, rule, metarule, environment, and observer changes.
- **Immutable-kernel disclosure** so “self-modification” always names what stayed fixed.
- **Metric hooks** that can later support research without baking a theory into the runtime.

These primitives are intended to sit beneath public educational products such as Repair Garden and later beneath controlled experiments.

## Install

```bash
npm install @temporal-self/core
```

The package is currently developed locally and consumed by prototype repositories as a packed dependency. Publishing can follow once the API settles.

## Minimal model

```ts
import { createTemporalLab, type TemporalModel } from "@temporal-self/core";

type State = { value: number; target: number };

const model: TemporalModel<State, null, number> = {
  id: "homeostat",
  version: "1",
  initialState: () => ({ value: 0, target: 10 }),
  step: (state) => {
    const next = state.value + Math.sign(state.target - state.value);
    return {
      state: { ...state, value: next },
      output: next,
      changes: [{ layer: "state", summary: "Moved toward target" }],
    };
  },
  interventions: {
    "rewrite-target": (state, payload) => ({
      state: { ...state, target: (payload as { target: number }).target },
      output: state.value,
      changes: [{ layer: "policy", summary: "Rewrote target" }],
    }),
  },
};

const lab = createTemporalLab({
  model,
  manifest: {
    title: "Two futures",
    question: "Can the same present state be redirected by hidden memory?",
    kernel: {
      name: "Homeostat v1",
      version: "1",
      immutable: ["scheduler", "numeric operations"],
      mutableLayers: ["state", "policy"],
    },
  },
});

lab.step(lab.rootBranchId, null);
const alternative = lab.fork(lab.rootBranchId);
lab.intervene(alternative, "rewrite-target", { target: -10 });
```

## Design principles

1. **History is data.** A finished state is insufficient for studying a temporal system.
2. **Intervene before interpreting.** Decoding a hidden variable does not show that the system uses it.
3. **Every change has a layer.** State change and rule change are different claims.
4. **Every soft system has a hard remainder.** Products and papers must publish their immutable kernel.
5. **Branches should share a past.** Counterfactual twins make philosophical questions experimentally legible.
6. **The engine stays theory-light.** Measures of agency, representation, novelty, and identity belong in explicit study modules.

## Repository scope

The `0.1` release is intentionally small. Durable storage, distributed execution, collaborative studies, data-frame adapters, and validated agency metrics remain outside the kernel until real products and experiments establish their requirements.

## Commands

```bash
npm run check
```

This runs strict type checking, tests, and the production package build.

## Status

Experimental. The API will change as the first products reveal which abstractions survive contact with users.
